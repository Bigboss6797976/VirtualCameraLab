#!/usr/bin/env python3
"""QR 码伪造攻击"""
import qrcode
import io
import base64
from typing import Optional
from PIL import Image, ImageDraw, ImageFont

class QRForgery:
    """支付 QR 码伪造"""

    def __init__(self):
        self.templates = {
            'alipay': self._generate_alipay_style,
            'wechat': self._generate_wechat_style,
            'usdt_trc20': self._generate_usdt_style,
            'usdt_erc20': self._generate_usdt_style,
        }

    def generate_payment_qr(self, amount: float, address: str, chain: str = "usdt_trc20") -> bytes:
        """生成伪造的支付 QR 码"""

        if chain == "usdt_trc20":
            qr_data = f"tron:{address}?amount={amount}&token=USDT"
        elif chain == "usdt_erc20":
            qr_data = f"ethereum:{address}?amount={amount}&token=USDT"
        elif chain == "alipay":
            qr_data = f"https://qr.alipay.com/fkx{base64.b64encode(f'{amount}:{address}'.encode()).decode()[:16]}"
        else:
            qr_data = address

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white").convert('RGB')
        img = self._add_fake_ui(img, amount, chain)

        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return buf.getvalue()

    def _add_fake_ui(self, img: Image.Image, amount: float, chain: str) -> Image.Image:
        """添加伪造的支付界面"""
        width, height = img.size
        new_height = height + 200
        new_img = Image.new('RGB', (width, new_height), 'white')
        new_img.paste(img, (0, 100))

        draw = ImageDraw.Draw(new_img)

        try:
            font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 32)
            font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
        except:
            font_large = ImageFont.load_default()
            font_small = font_large

        titles = {
            'usdt_trc20': 'USDT (TRC20) 转账',
            'usdt_erc20': 'USDT (ERC20) 转账',
            'alipay': '支付宝扫码付款',
            'wechat': '微信支付',
        }
        title = titles.get(chain, '扫码支付')
        draw.text((width//2 - 100, 20), title, fill='black', font=font_large)

        draw.text((width//2 - 80, height + 120), f"¥{amount:.2f}", fill='red', font=font_large)
        draw.text((width//2 - 60, height + 160), "请使用对应APP扫码", fill='gray', font=font_small)

        return new_img

    def generate_fake_receipt(self, tx_hash: str, amount: float, from_addr: str, to_addr: str) -> bytes:
        """生成伪造的交易凭证"""
        img = Image.new('RGB', (600, 800), '#f5f5f5')
        draw = ImageDraw.Draw(img)

        try:
            font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
            font_text = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
        except:
            font_title = ImageFont.load_default()
            font_text = font_title

        draw.rectangle([20, 20, 580, 780], fill='white', outline='#e0e0e0')

        draw.text((200, 50), "交易成功", fill='#07c160', font=font_title)
        draw.text((220, 100), f"-{amount:.2f} USDT", fill='black', font=font_title)

        details = [
            ("付款方", from_addr[:20] + "..."),
            ("收款方", to_addr[:20] + "..."),
            ("交易哈希", tx_hash[:30] + "..."),
            ("交易时间", "2024-01-01 12:00:00"),
            ("交易状态", "已确认 (12/12)"),
            ("Gas费用", "0.0001 TRX"),
        ]

        y = 180
        for label, value in details:
            draw.text((50, y), f"{label}:", fill='#666', font=font_text)
            draw.text((200, y), value, fill='black', font=font_text)
            y += 50

        draw.ellipse([400, 600, 550, 750], outline='#07c160', width=3)
        draw.text((420, 660), "已确认", fill='#07c160', font=font_title)

        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return buf.getvalue()
