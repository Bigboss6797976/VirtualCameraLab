#!/usr/bin/env python3
"""系统控制模块"""
import os
import sys
import psutil
import platform
import subprocess
import socket
from datetime import datetime
from typing import Optional

class SystemModule:
    """系统控制"""

    def __init__(self):
        self.hostname = socket.gethostname()

    def info(self) -> str:
        """获取详细系统信息"""
        boot_time = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

        info = f"""
📊 **系统信息**
━━━━━━━━━━━━━━━━━━━━━
🖥️ 主机名: `{self.hostname}`
💻 平台: `{platform.system()} {platform.release()}`
🧠 处理器: `{platform.processor() or 'Unknown'}`
⚙️ 架构: `{platform.machine()}`

📈 **资源使用**
━━━━━━━━━━━━━━━━━━━━━
💾 内存: `{self._get_memory()}`
🔥 CPU: `{psutil.cpu_percent(interval=1)}%`
⏱️ 运行时间: `{self._get_uptime()}`
🚀 启动时间: `{boot_time}`

👥 **用户**
━━━━━━━━━━━━━━━━━━━━━
{self._get_users()}

🌐 **网络**
━━━━━━━━━━━━━━━━━━━━━
{self._get_network_info()}
"""
        return info

    def _get_memory(self) -> str:
        mem = psutil.virtual_memory()
        return f"{mem.used // (1024**3)}GB / {mem.total // (1024**3)}GB ({mem.percent}%)"

    def _get_uptime(self) -> str:
        uptime = datetime.now() - datetime.fromtimestamp(psutil.boot_time())
        hours, remainder = divmod(uptime.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{uptime.days}天 {hours}小时 {minutes}分"

    def _get_users(self) -> str:
        users = psutil.users()
        if not users:
            return "无活跃用户"
        return "\n".join([
            f"• `{u.name}` @ `{u.host or 'local'}` (登录: {datetime.fromtimestamp(u.started).strftime('%H:%M')})"
            for u in users
        ])

    def _get_network_info(self) -> str:
        interfaces = []
        for name, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    interfaces.append(f"• `{name}`: `{addr.address}`")
        return "\n".join(interfaces) or "无网络接口"

    def processes(self, limit: int = 15) -> str:
        """列出进程"""
        procs = []
        for p in sorted(psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']),
                       key=lambda x: x.info['cpu_percent'] or 0, reverse=True)[:limit]:
            try:
                procs.append(
                    f"`{p.info['pid']:>6}` | `{p.info['name'][:20]:<20}` | "
                    f"CPU:{p.info['cpu_percent'] or 0:>5.1f}% | MEM:{p.info['memory_percent'] or 0:>5.1f}%"
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return "📋 **进程列表 (Top {})**\n━━━━━━━━━━━━━━━━━━━━━\n".format(limit) + "\n".join(procs)

    def kill(self, pid: int) -> str:
        """结束进程"""
        try:
            p = psutil.Process(pid)
            name = p.name()
            p.terminate()
            return f"✅ 已终止进程 `{pid}` (`{name}`)"
        except psutil.NoSuchProcess:
            return f"❌ 进程 `{pid}` 不存在"
        except psutil.AccessDenied:
            return f"🚫 无权限终止进程 `{pid}`"

    def shell(self, command: str, timeout: int = 30) -> str:
        """执行 Shell 命令"""
        try:
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                timeout=timeout, cwd=os.getcwd()
            )
            output = result.stdout + result.stderr
            if not output.strip():
                return "✅ 命令执行成功 (无输出)"
            return f"```\n{output[:4000]}\n```"
        except subprocess.TimeoutExpired:
            return "⏱️ 命令执行超时"
        except Exception as e:
            return f"❌ 错误: `{str(e)}`"

    def screenshot(self, quality: int = 85) -> Optional[bytes]:
        """屏幕截图"""
        try:
            from PIL import Image
            import io

            if platform.system() == "Linux":
                result = subprocess.run(
                    ["scrot", "-q", str(quality), "-"],
                    capture_output=True, timeout=10
                )
                if result.returncode == 0:
                    return result.stdout

            import pyautogui
            img = pyautogui.screenshot()
            buf = io.BytesIO()
            img.save(buf, format='JPEG', quality=quality)
            return buf.getvalue()

        except Exception as e:
            print(f"Screenshot error: {e}")
            return None

    def reboot(self) -> str:
        """重启系统"""
        os.system("reboot" if platform.system() != "Windows" else "shutdown /r /t 0")
        return "🔄 正在重启..."

    def shutdown(self) -> str:
        """关机"""
        os.system("shutdown -h now" if platform.system() != "Windows" else "shutdown /s /t 0")
        return "🔴 正在关机..."
