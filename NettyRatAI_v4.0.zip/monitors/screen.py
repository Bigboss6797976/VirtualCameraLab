#!/usr/bin/env python3
"""屏幕监控"""
import os
import io
import time
import threading
from typing import Optional, Callable
from datetime import datetime

class ScreenMonitor:
    """屏幕监控"""

    def __init__(self):
        self.recording = False
        self.record_thread = None
        self.frames = []
        self.callback: Optional[Callable] = None

    def capture(self, quality: int = 85) -> Optional[bytes]:
        """单张截图"""
        try:
            import pyautogui
            from PIL import Image

            screenshot = pyautogui.screenshot()
            buf = io.BytesIO()
            screenshot.save(buf, format='JPEG', quality=quality)
            return buf.getvalue()
        except Exception as e:
            print(f"Screen capture error: {e}")
            return None

    def start_live(self, interval: float = 2.0, callback=None):
        """开始实时屏幕监控"""
        if self.recording:
            return "已经在监控中"

        self.recording = True
        self.callback = callback
        self.frames = []

        def capture_loop():
            while self.recording:
                frame = self.capture(quality=60)
                if frame and self.callback:
                    self.callback(frame)
                time.sleep(interval)

        self.record_thread = threading.Thread(target=capture_loop, daemon=True)
        self.record_thread.start()
        return "✅ 屏幕监控已启动"

    def stop_live(self) -> str:
        """停止监控"""
        self.recording = False
        if self.record_thread:
            self.record_thread.join(timeout=2)
        return "🛑 屏幕监控已停止"

    def record_video(self, duration: int = 10, fps: int = 5) -> Optional[bytes]:
        """录制屏幕视频 (GIF)"""
        try:
            import imageio
            import pyautogui

            frames = []
            interval = 1.0 / fps

            for _ in range(duration * fps):
                img = pyautogui.screenshot()
                frames.append(img)
                time.sleep(interval)

            buf = io.BytesIO()
            frames[0].save(
                buf, format='GIF', save_all=True,
                append_images=frames[1:], duration=int(1000/fps), loop=0
            )
            return buf.getvalue()

        except Exception as e:
            print(f"Video record error: {e}")
            return None
